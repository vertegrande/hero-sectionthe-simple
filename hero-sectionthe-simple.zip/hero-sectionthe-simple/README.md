# Hero section - The simple

A Pen created on CodePen.io. Original URL: [https://codepen.io/shadeed/pen/NWzrjVR/83da07fda0c07756629e660b1bc7e69f](https://codepen.io/shadeed/pen/NWzrjVR/83da07fda0c07756629e660b1bc7e69f).

